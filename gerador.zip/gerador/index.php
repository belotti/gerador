<!DOCTYPE html>
<?php
require ("config.php");
?>
<html>
  <head>
    <meta content="text/html" charset="utf-8" http-equiv="content-type">
    <?php include ("links-css.php"); ?>

    <title>Login</title>
  </head>
  <body id="tela">
    <a id="btn_cadastrar" class="btn btn-default" href="cadastro-professor.php" role="button">Cadastrar</a>
    <div id="login">
      <div class="logo">
        <img src="css/imagens/logo.png" width="200" height="58" />
      </div>
      <div id="formulario_login">
        <form name="form_login" method="post" action="">
          <div class="form-group">
            <label for="prontuario">Prontuario: </label>
              <input id="campo_login" class="form-control" type="text" name="prontuario" required autofocus />
          </div>
          <div class="form-group">
            <label for="senha">Senha: </label>
              <input id="campo_login" class="form-control" type="password" name="senha" required />
          </div>
          <input id="btn_entrar" class="btn btn-default" type="submit" value="Entrar" name = "button">
        </form>
      </div>
    </div>
  </body>
</html>

<?php
  if (isset($_POST["button"])) {
    $prontuario = mysqli_real_escape_string($mysqli, $_POST["prontuario"]);
    $senha = mysqli_real_escape_string($mysqli, $_POST["senha"]);

    if($prontuario == "" || $senha == "") {
      echo "<script> alert('Preencha todos os campos!'); </script>";
      return true;
    }

  $select = $mysqli->query("SELECT * FROM professor WHERE prontuario='$prontuario'");
  $row = $select->num_rows;
  $get = $select->fetch_array();
  $nome = $get['nome'];
  $id_professor = $get['id_professor'];

  if ($row > 0) {
    if (hash_equals($get['senha'], crypt($senha, $get['senha']))) {
      session_start();
      $_SESSION['id_professor']=$id_professor;
      header("Location://localhost/gerador/tela-inicial.php");
      } else {
          echo "<script> alert('Usuário ou senha incorreto!'); </script>";
        }
    }
  }
?>
