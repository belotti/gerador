<!DOCTYPE html>
<html>
  <?php require ("config.php") ?>
  <head>
    <meta charset="utf-8">
    <?php include ("links-css.php") ?>
    <title>Gerar Prova</title>
  </head>
  <body id="tela">
    <header>
      <?php include ("dash.php"); ?>
    </header>

    <div class="container">

      <div class="row">
        <div class="col-xs-12">
          <form name="materia" method="post" action="">
            <div id="selecao_materia" class="col-sm-offset-5">
              <label for="id_materia" >Escolha a Matéria:</label>
               <select class="form-control" name="id_materia">
                 <option>Escolha a Matéria</option>
                   <?php
                   $query = $mysqli->query("SELECT * FROM materia");
                    while($reg = $query->fetch_array()) {
                      echo '<option value="'.$reg["id_materia"].'">'.$reg["nome"].'</option>';
                    }

                   ?>
                </select>
            </div>
            <div id="selecao_materia" class="col-sm-offset-5">
              <label for="id_materia" >Escolha o Tema:</label>
               <select class="form-control" name="id_tema">
                 <option>Escolha o Tema</option>
                   <?php
                   $query = $mysqli->query("SELECT * FROM tema");
                    while($reg = $query->fetch_array()) {
                      echo '<option value="'.$reg["id_tema"].'">'.$reg["nome"].'</option>';
                    }
                   ?>
                </select>
            </div>
            <div id="btn_pesquisar" class="col-sm-offset-5">
              <button type="submit" class="btn btn-default" name="button">Pesquisar</button>
            </div>
          </form>
        </div>
      </div>

      <div class="row">
        <div class="col-xs-12">
          <form action="questoes-selecionadas.php" method="post">
            <?php
              if (isset($_POST["button"])) {
                $id_materia = mysqli_real_escape_string($mysqli, $_POST["id_materia"]);
                $id_tema = mysqli_real_escape_string($mysqli, $_POST["id_tema"]);

                if($id_materia == "") {
                  echo "<script> alert('Preencha o registro!'); </script>";
                  return true;
                }
                if($id_tema == "") {
                  echo "<script> alert('Preencha o registro!'); </script>";
                  return true;
                }

                $select = $mysqli->query("SELECT * FROM questao WHERE id_materia='$id_materia' AND id_tema='$id_tema'");
                $row = $select->num_rows;
                if ($row < 1) {
                  echo "<script> alert('Nenhuma questao foi listada'); </script>";
                }
                while($dados = $select->fetch_array()) {
            ?>
            <div class="container bordas">
              <div class="form-group" style="margin-top: 20px;">
                <textarea class="pergunta_resposta form-control" rows="4" disabled><?php echo $dados["pergunta"]; ?></textarea>
              </div>

              <div class="form-group">
                <textarea class="pergunta_resposta form-control" rows="4" disabled><?php echo $dados["resposta"]; ?></textarea>
              </div>

              <div class="form-group">
                <label id="check" for="marcar"><input name="check_list[]" value="<?php echo $dados["id_questao"]; ?>" type="checkbox">Selecionar Questao</label>
              </div>
            </div>

            <?php
                }
              }
            ?>

            <div id="btn_pesquisar" class="col-sm-offset-5">
              <button type="submit" class="btn btn-default" name="selecionar">Prosseguir</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <footer>
      <?php include ("footer.php"); ?>
    </footer>
  </body>
</html>
