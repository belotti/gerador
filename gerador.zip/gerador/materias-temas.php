<!DOCTYPE html>
<html>
  <?php require ("config.php") ?>
  <head>
    <meta charset="utf-8">
    <?php include ("links-css.php") ?>
    <title>Inserir Materias e Temas</title>
  </head>
  <body id="tela">
    <header>
      <?php include ("dash.php") ?>
    </header>

    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <form name="form_registro" method="post" enctype="multipart/form-data" action="">
            <div class="container">
              <div class="row">
                <div id="campo_cadastro_materia" class="col-md-2 col-md-offset-4">
                  <label for="titulo">Inserir Matéria:</label>
                  <input class="form-control" placeholder="Nome da Materia" name="materia" type="text" size="100" />
                </div>

                <div class="col-md-2">
                  <input id="btn_salvar_materia_tema" type="submit" class="btn btn-success  btn-lg" value="Salvar Materia" name="salvar_materia"/>
                  <a id="btn_salvar_materia_tema" href=tela-inicial.php class="btn btn-warning btn-lg" role="button">Cancelar</a>
                </div>
              </div>

              <div id="salvar_tema" class="row">
                <div id="campo_salvar_tema" class="col-md-3 col-md-offset-2">
                  <label for="titulo">Inserir Tema:</label>
                  <input class="form-control" placeholder="Nome do Tema" name="tema" type="text" size="100" />
                </div>

                <div id="campo_salvar_tema" class="col-md-3">
                  <label for="tema_materia">Inserir Matéria do Tema:</label>
                  <input class="form-control" placeholder="Nome da Materia" name="materia_tema" type="text" size="100" />
                </div>

                <div class="col-md-2">
                  <input id="btn_salvar_materia_tema" type="submit" class="btn btn-success btn-lg" value="Salvar Tema" name="salvar_tema"/>
                  <a id="btn_salvar_materia_tema" href=tela-inicial.php class="btn btn-warning btn-lg" role="button">Cancelar</a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>

        <?php
          if (isset($_POST["salvar_materia"])) {
            $materia = mysqli_real_escape_string($mysqli,$_POST["materia"]);
            $select = $mysqli->query("SELECT * FROM materia");
            if ($select) {
              $row = $select->num_rows;
              if($row < -1) {
                echo "<script> alert ('Algo deu errado!'); </script>";
              } else {
                $insert = $mysqli->query ("INSERT INTO `materia` (`nome`) VALUES ('$materia')");
                echo "<script> alert ('Registrado com sucesso!'); location.href='tela-inicial.php' </script>";
                }
            }
          }
        ?>

        <?php
          if (isset($_POST["salvar_tema"])) {
            $tema = mysqli_real_escape_string($mysqli,$_POST["tema"]);
            $materia_tema = mysqli_real_escape_string($mysqli,$_POST["materia_tema"]);
            $select = $mysqli->query("SELECT * FROM tema");
            $materia_tema_id = $mysqli->query("SELECT `id_materia` FROM materia WHERE nome='$materia_tema'");

            $id_materia_row = $materia_tema_id->num_rows;
            if ($id_materia_row < 1) {
              echo "<script> alert ('Materia Invalida'); </script>";
            } else {
              $get = $materia_tema_id->fetch_array();
              $id_materia = $get['id_materia'];
              if ($select) {
                $row = $select->num_rows;
                if($row < -1) {
                  echo "<script> alert ('Algo deu errado!'); </script>";
                } else {
                  $insert = $mysqli->query ("INSERT INTO
                    `tema` (`nome`, `id_materia`) VALUES ('$tema', '$id_materia')");
                  echo "<script> alert ('Registrado com sucesso!'); location.href='tela-inicial.php' </script>";
                  }
              }
            }
          }
        ?>

        <div class="col-xs-12">
          <div class="container">
            <div class="row">
              <table class="table table-bordered table-hover table-condensed table-responsive">
                <thead>
                  <tr class="active">
                    <th>Registro</th>
                    <th>Nome da Matéria</th>
                  </tr>
                </thead>
                <tbody>
                <?php

                  $select = $mysqli->query("SELECT * FROM materia ORDER BY id_materia DESC"); //faço uma query para o número total de registros no banco
                  $numTotal = $select->num_rows;

                  if($numTotal > 0) {
                    for($x=0; $x<$numTotal; $x++) {
                      $dados = $select->fetch_assoc();
                ?>
                <tr class="info">
                  <td><?php echo $dados["id_materia"]; ?></td>
                  <td><?php echo $dados["nome"]; ?></td>
                </tr>
                <?php
                    }
                  } else {
                      echo "Nenhum registro!";
                    }
                ?>

                </tbody>
              </table>
            </div>
          </div>

          <div class="container">
            <div class="row">
              <table class="table table-bordered table-hover table-condensed table-responsive">
                <thead>
                  <tr class="active">
                    <th>Registro</th>
                    <th>Nome do Tema</th>
                    <th>ID da Materia do Tema</th>
                  </tr>
                </thead>
                <tbody>
                <?php

                  $select = $mysqli->query("SELECT * FROM tema ORDER BY id_tema DESC");
                  $numTotal = $select->num_rows;

                  if($numTotal > 0) {
                    for($x=0; $x<$numTotal; $x++) {
                      $dados = $select->fetch_assoc();
                ?>
                <tr class="info">
                  <td><?php echo $dados["id_tema"]; ?></td>
                  <td><?php echo $dados["nome"]; ?></td>
                  <td><?php echo $dados["id_materia"]; ?></td>
                </tr>
                <?php
                    }
                  } else {
                      echo "Nenhum registro!";
                    }
                ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <footer>
      <?php include ("footer.php") ?>
    </footer>
  </body>
</html>
