<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <?php include ("links-css.php") ?>
    <title>Ajuda</title>
  </head>
  <body id="tela">
    <header>
      <?php include ("dash.php") ?>
    </header>

    <div class="container">
      <div class="col-xs-12">
        <h3 align="center" id="inicio">Página de Ajuda</h3>
      </div>

      <div class="container">
        <div class="col-xs-12">
          <div class="list-group">
            <a href="#adicionar-questao" class="list-group-item">Sobre Adicionar Questões</a>
            <a href="#adicionar-materia-tema" class="list-group-item">Sobre Adicionar Matérias e Temas</a>
            <a href="#gerar-atividade" class="list-group-item">Sobre Gerar a Atividade</a>
          </div>
        </div>
      </div>


      <div class="col-xs-12" id="adicionar-questao">
        <div class="container">
          <h2>Sobre Adicionar Questões</h2> <a href="#inicio">Topo</a>
          <div class="well">
            <p>Nessa etapa será possível o cadastro de novas questões para o banco de dados</p>
            <p>A imagem a seguir mostra o botão para cadastrar novas questões:</p>
          </div>
          <div class="bordas" align="center" id="img-ajuda">
            <img src="css/imagens/btn-questoes.png" class="img-responsive" />
          </div>

          <div class="well">
            <p>Clicando nesse botão, será aberto a página de cadastro de questões</p>
          </div>

          <div class="bordas" align="center" id="img-ajuda">
            <img src="css/imagens/tela-questoes.png" class="img-responsive"/>
          </div>

          <div class="well">
            <p>Para o cadastro de questões é necessário preencher a Matéria e o Tema. Logo após essa etapa, escrever o título da questão e a sua resposta</p>
            <p>Para salvar as informações, é necessário clicar no botão Salvar</p>
          </div>
          <a href="#inicio">Topo</a>
        </div>
      </div>


      <div class="col-xs-12" id="adicionar-materia-tema">
        <div class="container">
          <h2>Sobre Adicionar Matérias e Temas</h2> <a href="#inicio">Topo</a>
          <div class="well">
            <p>Nessa etapa será possível o cadastro de novas matérias e temas para o banco de dados</p>
            <p>A imagem a seguir mostra o botão para cadastrar novas matérias e temas:</p>
          </div>
          <div class="bordas" align="center" id="img-ajuda">
            <img src="css/imagens/btn-materia-tema.png" class="img-responsive" />
          </div>

          <div class="well">
            <p>Clicando nesse botão, será aberto a página de cadastro de matérias e temas</p>
          </div>

          <div class="bordas" align="center" id="img-ajuda">
            <img src="css/imagens/tela-cadastro-materia-tema.png" class="img-responsive"/>
          </div>

          <div class="well">
            <p>Para o cadastro de matérias é necessário inserir no campo "Nome da Matéria" o nome da matéria e clicar em Salvar</p>
            <p>Para o cadastro de temas é necessário inserir no campo "Nome do Tema" o nome do tema e no campo "Nome da Matéria" o nome da matéria e clicar em Salvar</p>
            <p>É possível ver nas tabelas as matérias e os temas já cadastrados no banco de dados</p>
          </div>
          <a href="#inicio">Topo</a>
        </div>
      </div>

      <div class="col-xs-12" id="gerar-atividade">
        <div class="container">
          <h2>Sobre Gerar a Atividade</h2> <a href="#inicio">Topo</a>
          <div class="well">
            <p>Nessa etapa será possível gerar a atividade em PDF</p>
            <p>A imagem a seguir mostra o botão para gerar a atividade:</p>
          </div>
          <div class="bordas" align="center" id="img-ajuda">
            <img src="css/imagens/btn-atividade.png" class="img-responsive" />
          </div>

          <div class="well">
            <p>Clicando nesse botão, será aberto a página para selecionar a matéria e o tema</p>
            <p>Após escolher a matéria e o tema é necessário clicar em Pesquisar</p>
          </div>

          <div class="bordas" align="center" id="img-ajuda">
            <img src="css/imagens/tela-selecao.png" class="img-responsive"/>
          </div>

          <div class="well">
            <p>Fazendo isso, será mostrado todas as questões pertencente àquela matéria e tema</p>
            <p>Para selecionar a questão é necessário marcar o campo "Selecionar Questão"</p>
          </div>

          <div class="bordas" align="center" id="img-ajuda">
            <img src="css/imagens/marcar-questao.png" class="img-responsive"/>
          </div>

          <div class="well">
            <p>Uma vez que todas as questões estiverem marcadas, clicar em Prosseguir para serem utilizadas na atividade</p>
          </div>

          <div class="bordas" align="center" id="img-ajuda">
            <img src="css/imagens/btn-selecionar-questoes.png" class="img-responsive"/>
          </div>

          <div class="well">
            <p>Depois de ter clicado para selecionar as questões, será possível fazer edições na pergunta e na resposta antes de gerar o PDF</p>
            <p>Na imagem abaixo é mostrado a tela para editar</p>
          </div>

          <div class="bordas" align="center" id="img-ajuda">
            <img src="css/imagens/tela-edicao.png" class="img-responsive"/>
          </div>

          <div class="well">
            <p>Perceba que é possível também escrever o título da atividade e o nome da escola</p>
            <p>É possível editar livremente a pergunta e a resposta antes da geração da atividade</p>
            <p>Para a geração da Atividade é necessário clicar no botão Gerar Atividade</p>
            <p>Continuando, para a geração do gabarito será necessário clicar em Gabarito</p>
            <p>Para retornar, clicar no botão Voltar</p>
          </div>

          <div class="bordas" align="center" id="img-ajuda">
            <img src="css/imagens/btn-atividade-gabarito.png" class="img-responsive"/>
          </div>
          <a href="#inicio">Topo</a>
        </div>
      </div>
    </div>

    <footer>
      <?php include ("footer.php") ?>
    </footer>
  </body>
</html>
