<!DOCTYPE html>
<html>
<?php require ("config.php") ?>
  <head>
    <meta charset="utf-8">
    <?php include ("links-css.php") ?>
    <title>Tela Inicial</title>
  </head>
  <body id="tela">
    <?php
      include ("dash.php");
      include ("footer.php");
    ?>
  </body>
</html>
