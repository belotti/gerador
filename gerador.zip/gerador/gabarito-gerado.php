<?php
  require ("pdf/fpdf.php");
  $pdf = new FPDF();
  $pdf->AddPage();

  $pdf->SetFont('Arial','B',24);
  $pdf->SetY(20);
  $pdf->Cell(0,0,'Gabarito',0,0,'C');

  $pdf->SetFont('Arial','',12);
  $contador_resposta=1;
  if (isset($_POST['resposta'])) {
    foreach ($_POST['resposta'] as $key => $value) {
      $value = utf8_decode($value);
      $pdf->Ln(20);
      $pdf->Write(10,$contador_resposta.') '.$value);
      $contador_resposta++;
    }
  }
  $pdf->Output();
 ?>
