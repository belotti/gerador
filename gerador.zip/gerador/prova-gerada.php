<?php
  require ("pdf/fpdf.php");
  $pdf = new FPDF();

  $pdf->AddPage();

  $pdf->SetFont('Arial','B',24);
  $pdf->SetY(20);
  $pdf->Cell(0,0,utf8_decode($_POST['nome_atividade']),0,0,'C');

  $pdf->SetFont('Arial','B',16);
  $pdf->SetY(30);
  $pdf->Cell(0,0,utf8_decode($_POST['nome_escola']),0,0,'C');

  $pdf->SetFont('Arial','B',16);
  $pdf->SetY(50);
  $pdf->Write(0,'Nome:');

  $pdf->SetFont('Arial','',12);
  $contador_pergunta=1;
  if (isset($_POST['pergunta'])) {
    foreach ($_POST['pergunta'] as $key => $value) {
      $value = utf8_decode($value);

      $pdf->Ln(20);
      $pdf->Write(10,$contador_pergunta.') '.$value);
      $contador_pergunta++;
    }
  }

  $pdf->Output();
 ?>
