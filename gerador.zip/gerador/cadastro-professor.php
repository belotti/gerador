<!DOCTYPE html>
<html>
  <?php
    require ("config.php");
  ?>
  <head>
    <meta charset="utf-8">
    <?php include ("links-css.php") ?>
    <title>Cadastro de Professores</title>
  </head>
  <body id="tela">

    <a id="btn_login" class="btn btn-default" title="Faça login!" href="index.php" role="button">Login</a>
    <div id="login">
      <div class="logo">
        <img src="css/imagens/logo.png" width="200" height="58" />
      </div>

      <div id="formulario_login">
        <form name="form_cadastro" method="post" action="">
          <div class="form-group">
            <label for="nome">Nome: </label>
             <input id="campo" type="text" class="form-control" name="nome" required autofocus />
          </div>

          <div class="form-group">
            <label for="prontuario">Prontuario: </label>
             <input id="campo" type="text" class="form-control" name="prontuario" required />
          </div>

          <div class="form-group">
            <label for="email">E-mail: </label>
             <input id="campo" type="text" class="form-control" name="email" required />
          </div>

          <div class="form-group">
            <label for="senha">Senha: </label>
             <input  id="campo" type="password" class="form-control" name="senha" required />
          </div>

          <input type="submit" id="btn_cadastro" class="btn btn-default" value="Cadastrar" name="cadastro"/>
        </form>
      </div>
    </div>
  </body>
</html>

<?php
  if (isset($_POST["cadastro"])) {
    $nome = mysqli_real_escape_string($mysqli,$_POST["nome"]);
    $prontuario = mysqli_real_escape_string($mysqli,$_POST["prontuario"]);
    $email = mysqli_real_escape_string($mysqli,$_POST["email"]);
    $senha = mysqli_real_escape_string($mysqli,$_POST["senha"]);

    if ($nome == "" || $prontuario == "" || $email == "" || $senha == "") {
      echo "<script> alert ('Preencha todos os campos!'); </script>";
      return true;
    }
    $select = $mysqli->query("SELECT * FROM professor WHERE prontuario='$prontuario'");
    if ($select) {
      $row = $select->num_rows;
      if($row > 0) {
        echo "<script> alert ('Já existe um usuário com este prontuario! Contate o suporte!'); </script>";
      } else {
        $cost = 5;
        $salt = strtr(base64_encode(mcrypt_create_iv(16, MCRYPT_DEV_URANDOM)), '+', '.');
        $salt = sprintf("$2a$%02s$", $cost) . $salt;
        $hash = crypt($senha, $salt);
          $insert = $mysqli->query("INSERT INTO `professor` (`nome`, `prontuario`, `email`, `senha`)
            VALUES ('$nome', '$prontuario', '$email', '$hash')");
          if ($insert) {
            echo "<script> alert ('Usuário registrado com sucesso!'); location.href='index.php' </script>";
          } else {
              echo $mysqli->error;
            }
        }
    } else {
      echo $mysqli->error;
    }
  }
?>
