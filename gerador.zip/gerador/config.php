<?php
  $user = "gerador";
  $serv = "localhost";
  $pass = "gerador";
  $data = "gerador";

  $mysqli = new mysqli($serv, $user, $pass, $data);
    if ($mysqli->connect_error){
      echo "ERRO AO CONECTAR AO DATABASE";
      exit();
  } else {
    echo "";
    }
?>
