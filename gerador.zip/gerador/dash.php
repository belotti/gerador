<?php
  require ("config.php");

  session_start();
  $id_professor = $_SESSION['id_professor'];

  if (isset($_GET["action"]) AND $_GET["action"] == "sair") {
    session_destroy();
    header ("Location://localhost/gerador/index.php");
  }
?>
  <div class="container">
    <a href="?action=sair"
      class="btn btn-danger pull-right col-xs-2" role="button">Sair</a>
    <img src="css/imagens/logo.png" class="img-responsive" />

    <div class="btn-group btn-group-justified" role="group" aria-label="...">

      <div class="btn-group btn-lg" role="group">
        <a href="inserir-questao.php" target="_self"><button type="button" class="btn btn-default">
        <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Nova Questão  </button></a>
      </div>

      <div class="btn-group btn-lg" role="group">
        <a href="materias-temas.php" target="_self"><button type="button" class="btn btn-default">
        <span class="glyphicon glyphicon glyphicon-list-alt" aria-hidden="true"></span> Cadastro de Matérias e Temas</button></a>
      </div>

      <div class="btn-group btn-lg" role="group">
        <a href="gerar-prova.php" target="_self"><button type="button" class="btn btn-default">
        <span class="glyphicon glyphicon-save-file" aria-hidden="true"></span> Gerar Atividade</button></a>
      </div>

      <div class="btn-group btn-lg" role="group">
        <a href="ajuda.php" target="_self"><button type="button" class="btn btn-default">
        <span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span> Ajuda</button></a>
      </div>
    </div>
    <label for="id_professor" name="id_professor">Seu ID:
      <?php echo "$id_professor"?></label>
  </div>
