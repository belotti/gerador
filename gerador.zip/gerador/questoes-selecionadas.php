<!DOCTYPE html>
<html>
  <?php require ("config.php") ?>
  <head>
    <meta charset="utf-8">
    <?php include ("links-css.php") ?>

    <script type="text/javascript">
      function onescolhaprofessor()
      {
           if(document.pressed == 'prova')
           {
                document.myform.action ="prova-gerada.php";
           } else
           if(document.pressed == 'gabarito')
           {
                document.myform.action ="gabarito-gerado.php";
           }
           return true;
       }
     </script>
    <title>Questoes Selecionadas</title>
  </head>
  <body id="tela">
    <header>
      <?php include ("dash.php"); ?>
    </header>

    <div class="container">


      <div class="row">
        <div class="col-xs-12">
          <h2>
            Edite suas Questoes ou Clique em Gerar Atividade
          </h2>
        </div>
      </div>

      <div class="row">
        <div class="col-xs-12">
          <form name="myform" onsubmit="return onescolhaprofessor();" target="_blank" method="post">

              <div id="campo_atividade_escola">
                <label for="nome">Nome da Atividade </label>
                  <input type="text" class="form-control" name="nome_atividade" required autofocus />
              </div>

              <div id="campo_atividade_escola">
                <label for="nome">Nome da Escola </label>
                  <input type="text" class="form-control" name="nome_escola" required />
              </div>
              <?php
                $contador_pergunta = 1;
                $array_selecionados=array();
                if(isset($_POST["selecionar"])) {
                  if (isset($_POST["check_list"])) {
                    foreach($_POST["check_list"] as $selecionados) {
                      $array_selecionados[]=$selecionados;
                    }
                  } else {
                    echo "Nenhuma questão foi selecionada";
                  }
                } else {
                  echo "Nenhuma questão foi selecionada";
                }

                foreach ($array_selecionados as $key => $value) {
                  $select = $mysqli->query("SELECT * FROM questao WHERE id_questao='$value'");
                  $reg = $select->fetch_array();
              ?>
                <div class="container bordas">
                  <p>Pergunta <?php echo $contador_pergunta; ?></p>

                  <div id="campo_pergunta">
                    <textarea class="form-control" rows="4"
                    name="pergunta[]" required><?php echo $reg["pergunta"] ?></textarea>
                  </div>

                  <p>Resposta <?php echo $contador_pergunta; ?></p>
                  <div id="campo_resposta">
                    <textarea class="form-control" rows="4"
                    name="resposta[]" required><?php echo $reg["resposta"] ?></textarea>
                  </div>
                </div>

              <?php
                $contador_pergunta++;
                }
              ?>
              <div id="btn_pesquisar" class="col-sm-offset-5">
                <button onclick="document.pressed=this.value" type="submit" class="btn btn-default"
                  value="prova" name="atividade">Gerar Atividade</button>
              </div>
              <div id="btn_pesquisar" class="col-sm-offset-5">
                <button onclick="document.pressed=this.value" type="submit" class="btn btn-default"
                  value="gabarito" name="atividade">Gabarito</button>
              </div>

          </form>
            <div id="btn_pesquisar" class="col-sm-offset-5">
              <a href="tela-inicial.php"><button class="btn btn-default">Voltar</button></a>
            </div>
        </div>
      </div>
    </div>



    <footer>
      <?php include ("footer.php"); ?>
    </footer>
  </body>
</html>
