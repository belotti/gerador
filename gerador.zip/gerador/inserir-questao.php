<!DOCTYPE html>
<html>
  <?php require ("config.php") ?>
  <head>
    <meta charset="utf-8">
    <?php include ("links-css.php") ?>
    <title>Nova Questao</title>
  </head>
  <body id="tela">
    <header>
      <?php include ("dash.php") ?>
    </header>

    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <form name="form_registro" method="post" enctype="multipart/form-data" action="">

              <div id="selecao_materia" class="col-sm-offset-5">
                <label for="id_materia" >Escolha a Matéria:</label>
                <select class="form-control" name="id_materia" required >
                  <option>Selecione</option>

                    <?php
                      $result_materias = "SELECT * FROM materia";
                      $resultado_materias = mysqli_query($mysqli, $result_materias);

                      while ($dados_materia = mysqli_fetch_assoc($resultado_materias)) {
                        $codigo_materia = $dados_materia['id_materia'];
                        $materia = $dados_materia['nome'];
                        echo "<option value='$codigo_materia'>$materia</option>";
                      }
                    ?>
                </select>
              </div>

              <div id="selecao_tema" class="col-sm-offset-5">
                <label for="id_materia" >Escolha o Tema:</label>
                <select class="form-control" name="id_tema" required >
                  <option>Selecione</option>

                    <?php
                      $result_temas = "SELECT * FROM tema";
                      $resultado_temas = mysqli_query($mysqli, $result_temas);

                      while ($dados_tema = mysqli_fetch_assoc($resultado_temas)) {
                        $codigo_tema = $dados_tema['id_tema'];
                        $tema = $dados_tema['nome'];
                        echo "<option value='$codigo_tema'>$tema</option>";
                      }
                    ?>
                </select>
              </div>

            <div id="campo_pergunta">
              <label for="pergunta">Título da questão:</label>
              <textarea class="form-control" rows="4" name="pergunta"required></textarea>
            </div>

            <div id="campo_resposta">
              <label for="resposta">Resposta para a questão:</label>
              <textarea class="form-control" rows="4" name="resposta"required></textarea>
            </div>

            <div id="btn_salvar">
              <input type="submit" class="btn btn-success btn-lg col-xs-6" value="Salvar" name="salvar"/>
              <a href=principal.php class="btn btn-warning btn-lg col-xs-6" role="button">Cancelar</a>
            </div>
          </form>
        </div>
      </div>
    </div>

  <?php
    if (isset($_POST["salvar"])) {

      $pergunta = mysqli_real_escape_string($mysqli,$_POST["pergunta"]);
      $resposta = mysqli_real_escape_string($mysqli,$_POST["resposta"]);
      $id_materia = mysqli_real_escape_string($mysqli,$_POST["id_materia"]);
      $id_tema = mysqli_real_escape_string($mysqli,$_POST["id_tema"]);


    $select = $mysqli->query("SELECT * FROM questao");
      if ($select){
        $row = $select->num_rows;
        if($row < -1) {
          echo "<script> alert ('Algo deu errado!'); </script>";
        } else {
          $insert = $mysqli->query ("INSERT INTO
            `questao` (`pergunta`, `resposta`, `id_materia`, `id_tema`, `id_professor`)
            VALUES ('$pergunta', '$resposta', '$id_materia', '$id_tema', '$id_professor')");
            echo "<script> alert ('Registrado com sucesso!'); location.href='tela-inicial.php' </script>";
          }
      }
    }
  ?>
  
  <footer>
    <?php include ("footer.php") ?>
  </footer>

  </body>
</html>
